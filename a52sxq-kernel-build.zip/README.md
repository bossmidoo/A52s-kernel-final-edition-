# a52sxq KernelSU-Next (manual hooks) build
1. Create a new GitHub repo, upload this folder's content (`.github/`, `patches/`).
2. Actions -> "Build a52sxq kernel" -> Run workflow.
3. Download the zip artifact. BACK UP boot + vendor_boot first, flash zip via recovery (AnyKernel3 keeps your ramdisk/vendor_boot).
Untested build: no guarantee. Keep the old boot.img to restore.
